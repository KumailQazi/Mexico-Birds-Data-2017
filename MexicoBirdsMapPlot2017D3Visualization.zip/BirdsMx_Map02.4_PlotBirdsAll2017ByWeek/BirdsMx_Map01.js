var width = 1200,
    height = 700;

var projection = d3.geoConicConformal()
    .rotate([102, 0])
    .center([0, 24])
    .parallels([17.5, 29.5])
    .scale(1850)
    .translate([width / 2, height / 2]);


var svg = d3.select("body").append("svg")
    .attr("width", width)
    .attr("height", height)
    //Zoom
    .call(d3.zoom().on("zoom", function () {
        svg.attr("transform", d3.event.transform)
}))
.append("g");

var g = svg.append("g");


// add circles to svg  
d3.csv("output_week.csv", function (error, data) {
    svg.selectAll("circle")
        .data(data)
        .enter().append("circle")
        .attr("cx", function (d) {
            return projection([d.lon, d.lat])[0];
        })
        .attr("cy", function (d) {
            return projection([d.lon, d.lat])[1];
        })
        //Circle size
        .attr("r", function (d) {
            return Math.sqrt(d.number / 3.1416);
        })
        .attr("fill", "#f9f8e3")
        .attr("opacity", ".3");
});


// Draw Map    
d3.json('mx.json', function (error, mx) {
    if (error) {
        return console.error(error);
    }
    svg.selectAll(".mun_name")
        .data(topojson.feature(mx, mx.objects.municipalities).features)
        .enter().append("path")
        .attr("d", d3.geoPath().projection(projection))
        .attr("class", "municipality");

    g.selectAll(".state_name")
        .data(topojson.feature(mx, mx.objects.states).features)
        .enter().append("path")
        .attr("d", d3.geoPath().projection(projection))
        .attr("class", "state");

});

    







